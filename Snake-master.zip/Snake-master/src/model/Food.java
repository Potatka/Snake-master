package model;


import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

public class Food {

    Circle foodCircle;
    Circle specialFood;
    int posY;
    int posX;
    public Food() {



    }

    public Circle spawnFood() {

        foodCircle = new Circle(15);
        foodCircle.relocate(150,300);

    return foodCircle;
    }
    public Circle spawnSpecialFood() {
        specialFood = new Circle(10, Color.YELLOW);
        specialFood.relocate(300,260);
        return specialFood;
    }

    public void checkSpecialFood(Pane pane, Rectangle snakeHead,Circle specialFood,boolean foodSpawned) {
        if(snakeHead.getBoundsInParent().intersects(specialFood.getBoundsInParent())) {
            System.out.println("Food check is positive");

            pane.getChildren().remove(specialFood);
            foodSpawned = false;
        }
        System.out.println("check running");
    }


}
